import pygame
from pygame.locals import *
import sys

#CONSTANTES PARA LA VENTANA
SCREEN_WIDTH  = 640
SCREEN_HEIGHT = 480

#FUNCION PRINCIPAL DEL JUEGO

def main():
	pygame.init()
	#Crea la ventana
	screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
	pygame.display.set_caption("Juego")
#Buecle principal del juego
	while True:
		for eventos in pygame.event.get():
			if eventos.type == pygame.QUIT:
				sys.exit(0)
	return 0
		
if __name__ == "__main__":
	main()
	
#NOTA: El pygame.init() se puede poner en la funcion como esta en este momento
#def main():
#pygame.init()
#...
#O tambien se puede poner en el if
#if __name__= "__main__"
#pygame.init()
#..
